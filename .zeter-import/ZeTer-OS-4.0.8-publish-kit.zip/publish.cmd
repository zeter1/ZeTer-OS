@echo off
cd /d "%~dp0"
py -3 publish.py
if errorlevel 1 echo Publication aborted; see error above.
pause
