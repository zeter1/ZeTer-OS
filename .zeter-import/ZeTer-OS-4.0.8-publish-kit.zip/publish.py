#!/usr/bin/env python3
"""Safely publish ZeTer OS 4.0.8 by applying local changes atop current main."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parent
EXPECTED_MAIN = "c1b113503261dcc82deab7c4238f2507dd0fa0f8"
DEFAULT_REPOSITORY = "https://github.com/zeter1/ZeTer-OS.git"
MESSAGE = "feat: publish ZeTer OS 4.0.8 prompt library and calculations"

def git(cwd: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", *args], cwd=cwd, text=True, encoding="utf-8", errors="replace", check=check)

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", default=DEFAULT_REPOSITORY, help="Clone source (for local dry-run testing)")
    parser.add_argument("--expected-main", default=EXPECTED_MAIN, help="Exact expected remote main commit SHA")
    parser.add_argument("--dry-run", action="store_true", help="Prepare changes without committing or pushing")
    parser.add_argument("--verify", action="store_true", help="Run full Python+Node smoke suite before push")
    options = parser.parse_args()
    if not shutil.which("git"):
        parser.error("Git is not installed or not on PATH")
    with tempfile.TemporaryDirectory(prefix="zeter-os-publish-") as temp:
        target = Path(temp) / "repo"
        git(BUNDLE, "clone", "--no-tags", "--branch", "main", options.repository, str(target))
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=target, text=True).strip()
        print("Current main:", head)
        if head != options.expected_main:
            raise RuntimeError(f"main has changed since preflight ({options.expected_main} -> {head}); refusing to overwrite remote changes")
        git(target, "apply", "--3way", "--index", str(BUNDLE / "source-delta.patch"))
        src_readme = (BUNDLE / "README-4.0.8.md").read_text(encoding="utf-8")
        original_readme = (target / "README.md").read_text(encoding="utf-8")
        contacts = "## Контакты для связи с разработчиком"
        if contacts not in src_readme or contacts not in original_readme:
            raise RuntimeError("README contact section missing; refusing to overwrite")
        # All additions on the remote since the local base are documentation-only.
        # Local README carries the same full contact links and the new version's usage guide.
        current_contacts = original_readme.split(contacts,1)[1].strip()
        incoming_contacts = src_readme.split(contacts,1)[1].strip()
        if current_contacts != incoming_contacts:
            raise RuntimeError("Remote contacts differ from archive; refusing to overwrite")
        (target / "README.md").write_text(src_readme, encoding="utf-8", newline="\n")
        src_changelog = (BUNDLE / "CHANGELOG-4.0.8.md").read_text(encoding="utf-8")
        remote_changelog = (target / "CHANGELOG.md").read_text(encoding="utf-8")
        header = "# История изменений\n\n"
        old_version_marker = "## [4.0.1]"
        if not src_changelog.startswith(header) or old_version_marker not in src_changelog:
            raise RuntimeError("Unexpected local CHANGELOG structure")
        if not remote_changelog.startswith(header) or old_version_marker not in remote_changelog:
            raise RuntimeError("Unexpected remote CHANGELOG structure")
        new_entries = src_changelog[len(header):src_changelog.index(old_version_marker)]
        if "## [4.0.8]" in remote_changelog:
            raise RuntimeError("Version 4.0.8 is already present in remote CHANGELOG")
        (target / "CHANGELOG.md").write_text(header + new_entries + remote_changelog[len(header):], encoding="utf-8", newline="\n")
        git(target, "add", "-A")
        git(target, "diff", "--cached", "--check")
        git(target, "diff", "--cached", "--stat")
        if options.verify:
            subprocess.run([sys.executable, "-m", "compileall", "-q", "run_zeter_os.py", "problem_logs.py", "tools", "build_support"],cwd=target,check=True)
            subprocess.run([sys.executable, "tools/check_project.py", "--strict-node"],cwd=target,check=True)
        if options.dry_run:
            print("DRY RUN: diff applies cleanly, no commit and no push")
            return 0
        git(target, "commit", "-m", MESSAGE)
        git(target, "push", "origin", "HEAD:main")
        print("Uploaded commit:", subprocess.check_output(["git", "rev-parse", "HEAD"],cwd=target,text=True).strip())
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, subprocess.CalledProcessError, OSError) as error:
        print(f"PUBLISH ABORTED: {error}", file=sys.stderr)
        sys.exit(1)
